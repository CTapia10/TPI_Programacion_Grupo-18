/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package integrado.prog2.enums;

public enum Estado {
    PENDIENTE,
    CONFIRMADO,
    TERMINADO,
    CANCELADO
}